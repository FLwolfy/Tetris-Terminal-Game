from Block import *
import random
import time

class Board:
    def __init__(self):
        self.cur_block = BaseBlock()
        self.board = [["\u25A2"] * 20 for _ in range(15)]
        self.putNewBlock()
    
    # check if current block is valid
    def isBlockValid(self, x:int, y:int)->bool:
        # your code here
        for i in range(len(self.cur_block.getShape())):
            for j in range(len(self.cur_block.getShape()[0])):
                if(self.cur_block.getShape()[i][j] == "\u25A3"):
                    if (y + i >= 15 or x + j >= 20 or x + j < 0): # out of three bounds: left, right, bottom
                        return False
                    elif (y + i >= 0 and "\u25A3" in self.board[y + i][x + j]): # overlaps with other block
                        return False
                                 
        return True
    
    # move the block downward by 1 positon if the move is valid, otherwise do nothing. return whether the move is successful
    def tryMoveDown(self)->bool:
        # your code here
        if (self.isBlockValid(self.cur_block.x, self.cur_block.y + 1)):
            self.cur_block.moveDown()
            return True
        return False
    
    # move the block left by 1 positon if the move is valid, otherwise do nothing 
    def tryMoveLeft(self)->None:
        # your code here
        if (self.isBlockValid(self.cur_block.x - 1, self.cur_block.y)):
            self.cur_block.moveLeft()
    
    # move the block right by 1 positon if the move is valid, otherwise do nothing 
    def tryMoveRight(self)->None:
        # your code here
        if (self.isBlockValid(self.cur_block.x + 1, self.cur_block.y)):
            self.cur_block.moveRight()
    
    # rotate the block counterclockwise by 90 degree if the rotate is valid, otherwise do nothing
    def tryRotateLeft(self)->None:
        self.cur_block.rotateLeft()
        if(not self.isBlockValid(self.cur_block.x, self.cur_block.y)):
            self.cur_block.rotateRight()
    
    # rotate the block clockwise by 90 degree if the rotate is valid, otherwise do nothing
    def tryRotateRight(self)->None:
        self.cur_block.rotateRight()
        if(not self.isBlockValid(self.cur_block.x, self.cur_block.y)):
            self.cur_block.rotateLeft()
    
    # write current shape to the board permanently
    def dump(self)->None:
        # your code here
        for i in range(len(self.cur_block.getShape())):
            for j in range(len(self.cur_block.getShape()[0])):
                if (self.cur_block.y + i >= 0 and self.cur_block.y + i < 15 and self.cur_block.x + j < 20 and self.cur_block.x + j >= 0): # within the board
                    if(self.cur_block.getShape()[i][j] == "\u25A3"):
                        self.board[self.cur_block.y + i][self.cur_block.x + j] = "\033[93m\u25A3\033[0m" # Yellow block

    # put a new block on the top of the board
    def putNewBlock(self)->None:
        # your code here
        rng = random.randint(0, 6)
        if(rng == 0):
            self.cur_block = IBlock()
        if(rng == 1):
            self.cur_block = JBlock()
        if(rng == 2):
            self.cur_block = LBlock()
        if(rng == 3):
            self.cur_block = OBlock()
        if(rng == 4):
            self.cur_block = ZBlock()
        if(rng == 5):
            self.cur_block = TBlock()
        if(rng == 6):
            self.cur_block = SBlock()
        
    # detect, color, and remove full rows, return whether the board has full rows
    def ColorNRemoveFullRows(self)->bool:
        tmp = [self.board[i][:] for i in range(15)]
        for row in tmp:
            if (row == ["\033[92m\u25A3\033[0m"] * 20):
                self.board.remove(["\033[92m\u25A3\033[0m"] * 20) # Remove full rows
                self.board.insert(0, ["\u25A2"] * 20)

        hasFullrows = False
        for row in range(len(tmp)):
            if (tmp[row] == ["\033[93m\u25A3\033[0m"] * 20):
                self.board[row] = ["\033[92m\u25A3\033[0m"] * 20 # Add green color
                hasFullrows = True
        return hasFullrows
    
    # detect loss, if loss return True, else False
    def detectLoss(self)->bool:
        topRow = self.board[0]
        return "\033[93m\u25A3\033[0m" in topRow
    
    # return the current board with block on it 
    def toString(self)->str:
        tmp = [self.board[i][:] for i in range(15)]
        for i in range(len(self.cur_block.getShape())):
            for j in range(len(self.cur_block.getShape()[0])):
                if (self.cur_block.y + i >= 0 and self.cur_block.y + i < 15 and self.cur_block.x + j < 20 and self.cur_block.x + j >= 0): # within the board
                    if(self.cur_block.getShape()[i][j] == "\u25A3"):
                        tmp[self.cur_block.y + i][self.cur_block.x + j] = '\033[94m\u25A3\033[0m' # blue blocks
        
        tmp_string = ''
        for r in range(len(tmp)):
            tmp_string += '\033[1;91m\u25A5\033[0m'
            for c in range(len(tmp[0])):
                tmp_string += tmp[r][c]
            tmp_string += '\033[1;91m\u25A5\033[0m\n'
           
        return '\033[1;91m' + '\u25A5' * 22 + '\n' + '\u25A5' * 22 + '\n' + '\033[0m' + tmp_string + '\033[1;91m' + '\u25A5' * 22 + '\n' + '\u25A5' * 22 + '\033[0m'