from Game import Game

def main()->None:
    # initialize and run the Tetris game
    game = Game()
    game.run()
    return

if __name__ == "__main__":
    main()
