from Board import Board
from KBHit import KBHit
import time

class Game:
    def __init__(self):
        self.board = Board()
        self.kb = KBHit() # a class that read input from the keyboard
        self.time_gap = 0
        self.round_start_time = 0
        self.is_loss = False

    # start the game
    def run(self)->None:
        # your code here
        while(True):
            difficulty = input("Enter Difficulty: easy, normal, hard\nYour Input: --> ")
            if (difficulty == "easy"):
                self.time_gap = 0.9
                break
            elif (difficulty == "normal"):
                self.time_gap = 0.4
                break
            elif (difficulty == "hard"):
                self.time_gap = 0.2
                break
            print("\nPlease enter correct difficulty: easy, normal, hard")
        print('Press ESC to quit the game...' + '\n' * 19)
            
        # main game loop
        self.round_start_time = time.time()
        while(not self.is_loss):
            # handle inputs
            kinput = ''         
            if self.kb.kbhit():
                while self.kb.kbhit(): # only get the most recent input
                    kinput = self.kb.getch()

                self.kb.set_normal_term()
                if (ord(kinput) == 27): # ESC to exit
                    break
                
            # update board
            self.update(kinput)
            self.display()
            
            # input interval
            time.sleep(0.05)
        
        # Finish text
        print("Game Finish!\n")
    
    # update all the game mechanics
    def update(self, input:str)->None:
        # handle user's inputs       
        if (input == 'q'):
            self.board.tryRotateLeft()
        if (input == 'e'):
            self.board.tryRotateRight()
        if (input == 'a'):
            self.board.tryMoveLeft()
        if (input == 'd'):
            self.board.tryMoveRight()
        if (input == 's'): # if s is pressed, drop the block immediately
            while(self.board.tryMoveDown()):
                pass
            self.endBlockRound()
         
        # move down if possible, otherwise end the current block round
        if(time.time() - self.round_start_time >= self.time_gap):
            self.round_start_time = time.time()
            if(not self.board.tryMoveDown()):
                self.endBlockRound()
    
    # end the current block round
    def endBlockRound(self)->None:
        self.board.dump()
        self.board.putNewBlock()
        
        # Detect Full rows
        if(self.board.ColorNRemoveFullRows()): # Giving color to full rows
            self.display()
            time.sleep(0.5) # 0.5s to show the full rows
            self.board.ColorNRemoveFullRows() # Remove full rows
        
        # Detect loss
        if(self.board.detectLoss()):
            self.is_loss = True
    
    # print board on the command line
    def display(self)->None:
        # your code here
        # "\033[F\033[K" * 19 means clear the previous output to avoid jittering
        print("\033[F\033[K" * 19 + self.board.toString(), flush=True) 
