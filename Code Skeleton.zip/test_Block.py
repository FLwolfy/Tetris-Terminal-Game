import unittest
from Block import BaseBlock

class TestBlock(unittest.TestCase):
    
    def test_moveDown(self):
        block = BaseBlock()
        self.assertEqual(block.x, 8)
        self.assertEqual(block.y, -4)
        block.moveDown()
        self.assertEqual(block.y, -3)
        self.assertEqual(block.x, 8)
        
if __name__ == '__main__':
    unittest.main()
